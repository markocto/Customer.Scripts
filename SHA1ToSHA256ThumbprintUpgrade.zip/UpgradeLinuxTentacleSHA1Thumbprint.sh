# Export the Tentacle's existing thumbprint / certificate to a text file

tentacle show-thumbprint --export-file="/tmp/thumbprint.txt"

# Generate a new SHA256 thumbprint & certificate and export it to a .PFX file

tentacle new-certificate --instance="<tentacle-instance-name>" --export-pfx="/tmp/MyNewCertificate.pfx" --pfx-password="<password>"

# Restart the Tentacle service
echo "Restarting the Tentacle service..."
sudo ./tentacle service --instance <named-tentacle-instance> --restart
echo "Successfully completed restarting the Tentacle service"